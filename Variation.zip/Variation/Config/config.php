<?php

return [
    'name' => 'Variation',
];
