<?php
 
 namespace Modules\Variation\Http\Controllers\Admin;

 use Illuminate\Http\Request;
 use Modules\Variation\Entities\Variation;
 use Modules\Variation\Entities\VariationValue;
 use Illuminate\Routing\Controller;
 
 class VariationController extends Controller
 {
     /**
      * Hiển thị danh sách dữ liệu.
      *
      * @return View
      */
     public function index(Request $request)
     {
         $sortableColumns = ['id', 'name', 'price', 'in_stock', 'updated_at'];
         $sortBy = $request->get('sort_by', 'id');
         if (!in_array($sortBy, $sortableColumns)) {
             $sortBy = 'id';
         }
         $sortOrder = $request->get('sort', 'desc');
         if (!in_array(strtolower($sortOrder), ['asc', 'desc'])) {
             $sortOrder = 'desc';
         }
 
         $perPage = $request->input('per_page', 5);
         $totalProducts = Variation::count();
         $variations = Variation::orderBy($sortBy, $sortOrder)->paginate($perPage);
 
         return view('variation::admin.variations.index', compact('variations', 'perPage', 'totalProducts'));
     }
 
     /**
      * Hiển thị form thêm dữ liệu mới.
      *
      * @return View
      */
     public function create()
     {
         return view('variation::admin.variations.create');
     }
 
     /**
      * Lưu dữ liệu mới vào cơ sở dữ liệu.
      *
      * @param Request $request
      * @return Response
      */
     public function store(Request $request)
     {
         $request->validate([
             'name' => 'required|string|max:255',
             'type' => 'required|string|max:255',
             'values' => 'required|array',
             'values.*.label' => 'required|string|max:255',
             'values.*.value' => 'required|string|max:255',
             'values.*.position' => 'nullable|integer',
         ]);
 
         $variation = Variation::create([
             'name' => $request->name,
             'type' => $request->type,
         ]);
 
         foreach ($request->values as $value) {
             VariationValue::create([
                 'variation_id' => $variation->id,
                 'label' => $value['label'],
                 'value' => $value['value'],
                 'position' => $value['position'] ?? null,
             ]);
         }
 
         return redirect()->route('admin.variations.index')->with('success', 'Dữ liệu đã được thêm thành công!');
     }
 
     /**
      * Hiển thị chi tiết dữ liệu (nếu cần).
      *
      * @param int $id
      * @return View
      */
     public function show($id)
     {
         $variation = Variation::findOrFail($id);
         return view('variation::admin.variations.show', compact('variation'));
     }
 
     /**
      * Hiển thị form sửa dữ liệu.
      *
      * @param int $id
      * @return View
      */
     public function edit($id)
     {
         $variation = Variation::findOrFail($id);
         return view('variation::admin.variations.edit', compact('variation'));
     }
 
     /**
      * Cập nhật dữ liệu vào cơ sở dữ liệu.
      *
      * @param Request $request
      * @param int $id
      * @return Response
      */
     public function update(Request $request, $id)
     {
         $request->validate([
             'name' => 'required|string|max:255',
             'type' => 'required|string|max:255',
             'values' => 'required|array',
             'values.*.label' => 'required|string|max:255',
             'values.*.value' => 'required|string|max:255',
             'values.*.position' => 'nullable|integer',
         ]);
 
         $variation = Variation::findOrFail($id);
         $variation->update([
             'name' => $request->name,
             'type' => $request->type,
         ]);
 
         // Xóa các giá trị cũ
         VariationValue::where('variation_id', $variation->id)->delete();
 
         // Thêm các giá trị mới
         foreach ($request->values as $value) {
             VariationValue::create([
                 'variation_id' => $variation->id,
                 'label' => $value['label'],
                 'value' => $value['value'],
                 'position' => $value['position'] ?? null,
             ]);
         }
 
         return redirect()->route('admin.variations.index')->with('success', 'Dữ liệu đã được cập nhật thành công!');
     }
 
     /**
      * Xóa bản ghi khỏi cơ sở dữ liệu.
      *
      * @param int $id
      * @return Response
      */
     public function destroy($id)
     {
         $variation = Variation::findOrFail($id);
         $variation->delete();
 
         return redirect()->route('admin.variations.index')->with('success', 'Dữ liệu đã được xóa thành công!');
     }
 
     public function bulkDelete(Request $request)
     {
         try {
             $ids = $request->ids;
             if ($request->ajax()) {
                 Variation::destroy($ids);
                 return response()->json(['message' => __('Thành công')]);
             }
         } catch (\Exception $ex) {
             report($ex);
             return response()->json([
                 'error' => true,
                 'message' => __('Admin::business-office.delete.failure')
             ]);
         }
     }
 }
 